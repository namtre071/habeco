$(document).ready(function() {
  $("a.fancybox").fancybox()
});